# Output spec

Every run produces one structured results file, `results.json`. The chat summary, `report.md`, and `report.html` are all rendered from it. The model writes the content once; scripts do the formatting and anything that can be computed.

The exact structure is in `assets/results.schema.json` (generated; edit `extras/build/build_schema.py` instead). This page explains it.

## results.json at a glance

| Section | What it holds | Produced by |
| --- | --- | --- |
| `run` | Run id, time, tool version, content hash of the skill files, model, execution (`single` or `isolated`), platform | Script |
| `document` | Full text, word count, sections (headings, or paragraph groups if there are none), and the key-sentence outline | Script |
| `inputs` | What the user gave: intended claim, stage, venue, feedback wanted, known gaps, prior feedback, reader overrides, house settings | User |
| `analysis` | Kind of piece; stage with source and basis; venue; field; whether it proposes something; the claim (stated or inferred); what matters at this stage; the plan line | Model (step 2) |
| `assumptions` | Each inferred fact, its basis, and whether the user confirmed it | Model (step 2) |
| `personas` | Each reader as adapted: reader type, briefing, stages, role (`stage` or `look_ahead`), adaptations, added context, full adapted text | Model + script |
| `persona_reviews` | Each reader's review, in the format in `persona-review-format.md`, including its related-work pointers | Model (step 4) |
| `related_work_check` | Each specific work a reader named, with its status (`verified` with a link, `cited_in_draft`, `not_found`, or `not_checked`), and whether a search ran | Model (step 5), completed by script |
| `key_sentence_check` | Verdict and up to five flagged paragraphs, or null if the check didn't run | Model (step 6) |
| `cold_read` | Method, batteries, every prompt with its answer (or null), and the claim check | Model (step 7) |
| `synthesis` | Issues (each now or later), dropped findings, tradeoffs, what's working, cold-read highlights, next steps (from the model); ranking, priority actions, parked issues, reader-specific findings (from script) | Model + script (step 8) |
| `quality` | Anchoring, reader distinctiveness, stance spread, assumption load, coverage, leaks, named-work counts, and the limitations to disclose (standing ones plus any that apply to this run) | Script |
| `prompts` | Recorded model calls (cold-read answers), with the draft replaced by `[[DOCUMENT]]` | Script |

### Conventions

- **Related-work references.** A reader's related-work item is `persona-id/rwN` (for example `field-expert/rw1`).
- **Finding references.** A reader finding is `persona-id/n`, its 1-based position in that reader's findings (for example `field-expert/2`). A key-sentence flag is `key-sentences/n`.
- **Issue indexes.** Issues are referred to by their 0-based position in `synthesis.output.issues`. `priority_actions` (now issues, best first, at most seven) and `parked` (later issues) are lists of these indexes.
- **Quotes** are verbatim from the draft; footnote text counts. `quality.anchoring` records any quote the script couldn't find.
- **Nothing is dropped silently.** Findings removed in synthesis stay in `persona_reviews` and are listed in `synthesis.output.dropped_findings` with the rule that removed them.

## Chat summary

1. **Plan line**, the stage (marked inferred if it was), and the claim (marked inferred if it was)
2. **Top priorities now:** the first three, one line each, plus how many issues were parked for later
3. **Cold read:** whether the claim, contribution, and stakes came through, if it ran
4. **Biggest tradeoff,** if any
5. **Who to ask next:** the first entry in the feedback plan
6. **Before you rely on this:** every limitation in `quality.limitations`, in full (see "Limitations to disclose" in `synthesis-rubric.md`)
7. **Link** to the HTML report

## HTML report

One self-contained file, rendered by `scripts/render_report.py` from `assets/report-template.html` with `results.json` embedded inline. It opens by double-click with no server or network access, prints cleanly, and follows the system's light or dark mode. With no embedded results, the same template is a viewer (`render_report.py --viewer`). Tabs:

1. **Overview:** "Before you rely on this" (every limitation) first, then the stage on a five-step ladder, the claim, top priorities, the cold-read result, who to ask next, the biggest tradeoff, run quality, what's working
2. **Now:** ranked issues for this stage, each expanding to what each reader said, plus tradeoffs; filterable by severity and reader
3. **Later:** issues parked for a later draft (shown only if there are any)
4. **Readers:** one tab per reader with main point, gut reaction, next step, look-for checks, findings, what to keep, and a section-by-section attention strip
5. **Key sentences:** the verdict, and the full outline with flagged paragraphs highlighted
6. **Cold read:** the claim check and each answer, or the prompts to copy if it didn't run
7. **Next steps:** who to ask next (with what to ask), related work (verified works linked, unchecked ones labeled, works not found left out), questions to answer before revising, assumptions to confirm, follow-up reviews
8. **Method:** run details, assumptions, readers as adapted, findings set aside, named works that couldn't be found, recorded prompts, the limitations again, and a download of `results.json`
