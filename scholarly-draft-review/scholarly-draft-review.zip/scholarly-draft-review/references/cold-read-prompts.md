# Cold-read prompts

This check asks: if someone who knows nothing about the draft reads it cold, does the claim come through? It stands in for the most basic test a nonexpert reader gives you ("what do you think my claim is?"), and for the AI summaries many readers now see before, or instead of, the paper itself.

## Rules for running the check

- **Fresh context every time.** No persona, no author's note, no intended claim, no framing, and no system prompt beyond the platform default. The AI sees only the draft and the prompt.
- **Paste format.** The draft first, then the prompt on a new line:

  ```
  [full draft text]

  [prompt]
  ```

- **Fixed wording.** Use the prompts below exactly, so runs are comparable.
- **One prompt per conversation.** Each prompt runs in its own fresh context, not as a follow-up.
- **Record everything verbatim.** Each prompt and full answer go into the results so the author can rerun them elsewhere.

## Which batteries run

| Battery | Runs at |
| --- | --- |
| Core | Every stage |
| Argument | `full`, `workshop`, `submission` |

## Core battery

| # | Prompt |
| --- | --- |
| 1 | Summarize this paper in three sentences. |
| 2 | What is the author's main argument? |
| 3 | What does this paper add that's new? |
| 4 | Why does this matter, and who should care? |

## Argument battery

| # | Prompt |
| --- | --- |
| 5 | What are the main steps of the argument, in order? |
| 6 | What are the weakest parts of this argument? |
| 7 | What would someone who disagrees with the author say? |

## Claim check

After the prompts run, compare the answers with the author's claim (stated, or inferred and marked so). Answer each with **yes**, **partly**, **no**, or **not applicable**, and quote the answer that shows it.

1. **Claim.** Did the AI state the author's claim, not just the topic? (Prompts 1, 2.)
2. **Contribution.** Did the AI identify what's new the way the author frames it? (Prompt 3.)
3. **Stakes.** Did the AI convey why it matters and to whom? (Prompts 1, 4.)
4. **Structure.** Did the steps of the argument come through in the author's order? (Prompt 5; not applicable at `idea` and `early`.)
5. **Prescription.** If the draft proposes something, did the proposal come through? (Prompts 1, 2; not applicable for descriptive pieces.)

A **no** becomes a high-severity issue and a **partly** a medium one. Each quotes both the draft passage and the AI's answer.

Prompts 6 and 7 aren't scored. Use them in the synthesis as a preview of objections: note any the readers didn't raise, and any that the draft already answers but the AI missed (which suggests the answer is buried).

If the claim was inferred rather than stated, say in the report that the check compares the AI's reading with the skill's inference, and that it's sharper when the author states the claim.
