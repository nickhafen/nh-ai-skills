"""Render a results.json as a markdown report (and a short chat summary).

Usage:
    python render_markdown.py results.json [--out report.md] [--summary]

Section order follows references/output-spec.md. Formatting only: every word of
content comes from results.json.
"""

import argparse
import json
import sys
from pathlib import Path

SEVERITY_LABEL = {"high": "High", "medium": "Medium", "low": "Low"}
STATUS_LABEL = {"clear": "Clear", "unclear_or_buried": "Unclear or buried", "missing": "Missing", "not_applicable": "n/a"}
ATTENTION_LABEL = {"read_closely": "read closely", "skimmed": "skimmed", "skipped": "skipped"}
STAGE_LABEL = {"idea": "Idea", "early": "Early draft", "full": "Full draft", "workshop": "Workshop draft",
               "submission": "Submission draft"}
READER_TYPE_LABEL = {"nonexpert": "Nonexpert", "expert": "Law-trained, outside the specialty", "Expert": "Specialist",
                     "gatekeeper": "Gatekeeper", "custom": "Custom reader"}
CHECK_LABEL = {"claim": "The claim", "contribution": "What's new", "stakes": "Why it matters",
               "structure": "The steps of the argument", "prescription": "The proposal"}
RESULT_LABEL = {"yes": "Came through", "partly": "Partly came through", "no": "Lost", "not_applicable": "n/a"}
WHEN_LABEL = {"now": "Now", "next_draft": "After the next draft", "before_submission": "Before you submit"}
PSEUDO = {"cold-read": "Cold read", "key-sentences": "Key-sentence outline"}
WORK_LABEL = {"verified": "Verified", "cited_in_draft": "Already cited in the draft",
              "not_checked": "Not checked: confirm it exists before relying on it",
              "kind": "Kind of work to search for"}
LISTENING_NOTE = ("When they respond, listen without defending. Ask \"Can you say more about that?\" rather than "
                  "explaining what you meant. If a reader found a passage unclear, it was unclear to that reader, "
                  "whatever you intended. Then respond to each comment, even if the response is to decide against it.")


def quote(text):
    text = " ".join((text or "").split())
    return f"> “{text}”" if text else ""


def names(results):
    table = {p["id"]: p["name"] for p in results["personas"]}
    table.update(PSEUDO)
    return table


def reader_list(ids, table):
    return ", ".join(table.get(i, i) for i in ids)


def issue_readers(issue):
    readers = {r["reader"] for r in issue.get("reasons", [])} | {ref.split("/")[0] for ref in issue["finding_refs"]}
    if issue["category"] == "cold_read_failure":
        readers.add("cold-read")
    if issue["category"] == "key_sentence":
        readers.add("key-sentences")
    return sorted(readers)


def related_work(results):
    """Every related-work pointer with its check status. Works searched for and not found are marked not_found."""
    checks = {i["ref"]: i for i in (results.get("related_work_check") or {}).get("items", [])}
    out = []
    for review in results["persona_reviews"]:
        for n, item in enumerate(review["output"].get("related_work", []), start=1):
            ref = f"{review['persona_id']}/rw{n}"
            check = checks.get(ref, {}) if item["specific"] else {}
            status = check.get("status", "not_checked") if item["specific"] else "kind"
            out.append({"ref": ref, "reader": review["persona_id"], "work": item["work"], "why": item["why"],
                        "confidence": item["confidence"], "status": status, "url": check.get("url"),
                        "note": check.get("note", "")})
    return out


def work_line(w, table=None):
    work = f"[{w['work']}]({w['url']})" if w.get("url") else w["work"]
    who = f"; {table.get(w['reader'], w['reader'])}" if table else ""
    return f"- {work} — {w['why']} *({WORK_LABEL[w['status']]}; {w['confidence']} confidence{who})*"


def limitation_lines(results):
    return [f"- **{x['title']}.** {x['text']}" for x in results["quality"]["limitations"]]


def stage_line(a):
    s = a["stage"]
    text = f"**Stage:** {STAGE_LABEL[s['id']]}"
    if s["source"] == "inferred":
        text += f" (inferred: {s['basis']}; tell me if that's wrong)"
    return text


def claim_line(a):
    c = a["claim"]
    if c["source"] == "inferred":
        return f"**Claim (inferred; if this is wrong, much of the feedback shifts):** {c['text']}"
    return f"**Claim (yours):** {c['text']}"


def issue_block(issue, n, ranked, table):
    tags = [SEVERITY_LABEL[issue["severity"]]]
    if ranked.get("convergent"):
        tags.append("several readers")
    if issue.get("depends_on_assumptions"):
        tags.append("depends on an assumption")
    out = [f"### {n}. {issue['title']}", "",
           f"*{' · '.join(tags)} — raised by {reader_list(issue_readers(issue), table)}*", ""]
    if issue["quote"]:
        out += [quote(issue["quote"]), ""]
    out += [issue["summary"], ""]
    if issue.get("direction"):
        out += [f"**Direction:** {issue['direction']}", ""]
    return out


def render_report(results):
    table = names(results)
    a = results["analysis"]
    out = [f"# Scholarly draft review: {results['document'].get('title') or a['piece_type']}", ""]
    out += [f"**Plan.** {a['plan_line']}", "", stage_line(a), "", claim_line(a), ""]
    out += ["## Before you rely on this", ""] + limitation_lines(results) + [""]

    synthesis = results.get("synthesis")
    issues = synthesis["output"]["issues"] if synthesis else []
    ranked = {r["issue_index"]: r for r in synthesis["ranked_issues"]} if synthesis else {}

    if synthesis:
        out += ["## Priority actions", "", f"What matters at this stage: {a['stage_focus']}", ""]
        for n, index in enumerate(synthesis["priority_actions"], start=1):
            out += issue_block(issues[index], n, ranked.get(index, {}), table)
        shown = set(synthesis["priority_actions"]) | set(synthesis["parked"])
        others = sorted((i for i in range(len(issues)) if i not in shown), key=lambda i: ranked.get(i, {}).get("rank", 999))
        if others:
            out += ["**Other issues to look at now**", ""]
            out += [f"- {issues[i]['title']} ({SEVERITY_LABEL[issues[i]['severity']].lower()}; "
                    f"{reader_list(issue_readers(issues[i]), table)})" for i in others] + [""]
        if synthesis["parked"]:
            out += ["## Park for later", "", "Real issues, but not for this stage. Come back to them in a later draft.", ""]
            for i in synthesis["parked"]:
                issue = issues[i]
                out.append(f"- **{issue['title']}** — {issue['summary']} *({reader_list(issue_readers(issue), table)})*")
            out.append("")

        tradeoffs = synthesis["output"].get("tradeoffs", [])
        if tradeoffs:
            out += ["## Tradeoffs", "", "Readers pull in different directions here. These are yours to decide.", ""]
            for t in tradeoffs:
                out += [quote(t["quote"]), ""]
                for side in t["sides"]:
                    out.append(f"- **{table.get(side['reader'], side['reader'])}** wants {side['wants']} — {side['why']}")
                if t.get("note"):
                    out += ["", t["note"]]
                out.append("")

    # Cold read
    cold = results.get("cold_read")
    if cold:
        ran = any(x.get("answer") for x in cold["answers"])
        out += ["## Does the claim come through a cold read?", ""]
        if ran:
            if cold.get("method") == "same_conversation":
                out += ["**Caution:** these answers were produced in the same conversation as the review, not in a "
                        "fresh context, so they may reflect what the reviewer already knew. Treat them as rough.", ""]
            else:
                out += ["The draft was given to a fresh AI assistant with no other context, one question at a time.", ""]
            if a["claim"]["source"] == "inferred":
                out += ["*The check compares the answers with the inferred claim above; it's sharper when you state "
                        "your claim.*", ""]
            cc = cold.get("claim_check")
            if cc:
                out += ["| Did it come through? | Result | Note |", "| --- | --- | --- |"]
                for c in cc["checks"]:
                    out.append(f"| {CHECK_LABEL[c['check']]} | {RESULT_LABEL[c['result']]} | {c['note'].replace('|', '/')} |")
                out.append("")
            if synthesis and synthesis["output"].get("cold_read_highlights"):
                out += [f"- {h['note']}" for h in synthesis["output"]["cold_read_highlights"]] + [""]
            for x in cold["answers"]:
                out += [f"<details><summary>“{x['prompt']}”</summary>", "", x["answer"] or "", "", "</details>", ""]
        else:
            out += ["To see whether a cold reader finds your claim, open a **new** chat in any AI assistant, paste "
                    "the draft, and ask one of these questions. Use a fresh chat for each, then compare the answers "
                    "with the claim you meant to make.", ""]
            for x in cold["answers"]:
                out += ["```", x["prompt"], "```"]
            out.append("")

    # Key sentences
    ks = results.get("key_sentence_check")
    outline = results["document"].get("key_sentences", [])
    if ks or outline:
        out += ["## Key-sentence outline", ""]
        if ks:
            out += [ks["verdict"], ""]
            for i, f in enumerate(ks["flags"], start=1):
                out += [f"{i}. **{f['paragraph_id']}** — {f['issue']}", "", "   " + quote(f["quote"]), ""]
        if outline:
            labels = {s["id"]: s["label"] for s in results["document"]["sections"]}
            out += ["<details><summary>The first sentence of every body paragraph</summary>", ""]
            current = None
            for k in outline:
                if k["section_id"] != current:
                    current = k["section_id"]
                    out += ["", f"**{labels.get(current, current)}**", ""]
                out.append(f"- *{k['id']}* {k['text']}")
            out += ["", "</details>", ""]

    # By reader
    out += ["## By reader", ""]
    personas = {p["id"]: p for p in results["personas"]}
    for review in results["persona_reviews"]:
        p = personas.get(review["persona_id"], {"name": review["persona_id"], "role": "stage", "reader_type": "custom"})
        o = review["output"]
        kind = READER_TYPE_LABEL.get(p.get("reader_type"), "")
        role = " · look-ahead reader" if p.get("role") == "look_ahead" else ""
        out += [f"### {p['name']}", "", f"*{kind}{role}*", "",
                f"**What they think it argues:** {o['main_point']}", "",
                f"**Gut reaction:** “{o['gut_reaction']}”", "",
                f"**Likely next step:** {o['likely_next_action']['action']} — {o['likely_next_action']['driver']}", ""]
        if o.get("look_for"):
            out += ["| They look for | Status | Note |", "| --- | --- | --- |"]
            for c in o["look_for"]:
                out.append(f"| {c['item']} | {STATUS_LABEL[c['status']]} | {c['note'].replace('|', '/')} |")
            out.append("")
        if o.get("findings"):
            out += ["**Findings**", ""]
            for i, f in enumerate(o["findings"], start=1):
                out += [f"{i}. **{f['issue']}** ({SEVERITY_LABEL[f['severity']].lower()})  ", f"   {f['why_it_matters']}", ""]
                out += ["   " + quote(f["quote"]), ""]
        if o.get("what_works"):
            out += ["**Keep**", ""]
            for w in o["what_works"]:
                out += [quote(w["quote"]), "", w["note"], ""]
        pointers = [w for w in related_work(results) if w["reader"] == review["persona_id"] and w["status"] != "not_found"]
        if pointers:
            out += ["**Would point you to**", ""] + [work_line(w) for w in pointers] + [""]
        skimmed = [e for e in o.get("attention_map", []) if e["attention"] != "read_closely" and e.get("would_miss")]
        if skimmed:
            out += ["**What they'd likely miss**", ""]
            out += [f"- {e['section_id']} ({ATTENTION_LABEL[e['attention']]}): {e['would_miss']}" for e in skimmed] + [""]

    if synthesis:
        working = synthesis["output"].get("whats_working", [])
        if working:
            out += ["## What's working", ""]
            for w in working:
                out += [quote(w["quote"]), "", f"{w['note']} *({reader_list(w['readers'], table)})*", ""]

        steps = synthesis["output"]["next_steps"]
        out += ["## Next steps", ""]
        if steps.get("revision_questions"):
            out += ["**Questions to answer before you revise.** The answers, and the writing, are yours.", ""]
            for rq in steps["revision_questions"]:
                title = issues[rq["issue_index"]]["title"] if 0 <= rq["issue_index"] < len(issues) else ""
                out += [f"- *{title}:* {rq['question']}"]
            out.append("")
        if steps.get("feedback_plan"):
            out += ["**Who to ask next**", "", "| When | Who | What to ask | Why |", "| --- | --- | --- | --- |"]
            for x in steps["feedback_plan"]:
                out.append(f"| {WHEN_LABEL[x['when']]} | {x['who']} | {x['ask']} | {x['why']} |".replace("\n", " "))
            out += ["", LISTENING_NOTE, ""]
        works = [w for w in related_work(results) if w["status"] != "not_found"]
        if works:
            method = (results.get("related_work_check") or {}).get("method")
            note = ("Specific works were looked up; ones that couldn't be found are left out." if method == "searched"
                    else "No search ran, so named works are unchecked."
                    if any(w["status"] == "not_checked" for w in works) else "")
            out += ["**Related work to check**", ""] + ([note, ""] if note else [])
            out += [work_line(w, table) for w in works] + [""]
        if steps.get("assumptions_to_confirm"):
            assumptions = {x["id"]: x["text"] for x in results.get("assumptions", [])}
            out += ["**Assumptions to confirm**", ""]
            out += [f"- {assumptions.get(x['assumption_id'], x['assumption_id'])} — {x['what_changes']}"
                    for x in steps["assumptions_to_confirm"]] + [""]
        if steps.get("follow_up_reviews"):
            out += ["**Follow-up reviews**", ""]
            out += [f"- {x['suggestion']} — {x['reason']}" for x in steps["follow_up_reviews"]] + [""]

    # Run quality
    q = results["quality"]
    out += ["## About this run", ""]
    rate = q["anchoring"]["rate"]
    out.append(f"- **Quotes checked:** {q['anchoring']['verified']} of {q['anchoring']['total']} findings quote the "
               f"draft verbatim" + ("." if rate in (None, 1.0) else " — the rest are paraphrases; check them."))
    for pair in q["distinctiveness"]["flagged"]:
        out.append(f"- **Overlap:** {table.get(pair['a'], pair['a'])} and {table.get(pair['b'], pair['b'])} raised "
                   "mostly the same issues; one of them may not be adding much.")
    if q["stance_spread"]["note"]:
        out.append(f"- **Stance:** {q['stance_spread']['note']}")
    cov = q["coverage"]
    if cov["attention_gaps"]:
        out.append("- **Likely to be skimmed by every reader:** " + "; ".join(g["label"] for g in cov["attention_gaps"]))
    if cov["review_gaps"]:
        out.append("- **Not closely reviewed by any reader in this run:** " + "; ".join(g["label"] for g in cov["review_gaps"]))
    if q["assumption_load"]["count"]:
        out.append("- **Unconfirmed assumptions:** " + "; ".join(q["assumption_load"]["key"]))
    rw = q["related_work"]
    if rw["specific"]:
        out.append(f"- **Named works:** {rw['specific']} named; {rw['verified']} verified, {rw['cited_in_draft']} "
                   f"already cited, {rw['not_checked']} not checked, {rw['not_found']} not found and left out.")
    if synthesis:
        known = [d for d in synthesis["output"].get("dropped_findings", []) if d["rule"] == "known_gap"]
        if known:
            out.append("- **Readers also noticed gaps you already know about:** " + "; ".join(d["note"] for d in known))
    out.append("")

    # Methodology
    run = results["run"]
    out += ["## Methodology", "",
            f"Run {run['id']} · {run['created_at']} · {run['platform']} · model {run['model']} · reader reviews in "
            f"{'one conversation' if run['execution'] == 'single' else 'separate conversations'} · skill content "
            f"{run['content_hash']}", ""]
    if results.get("assumptions"):
        out += ["**Assumptions**", ""]
        out += [f"- {x['text']} *({'confirmed' if x['confirmed'] else 'inferred'}: {x['basis']})*"
                for x in results["assumptions"]] + [""]
    for p in results["personas"]:
        out += [f"<details><summary>{p['name']}, as adapted for this draft ({p['briefing']})</summary>", "",
                p["adapted_text"], "", "</details>", ""]
    return "\n".join(out).rstrip() + "\n"


def render_summary(results, report_path=None):
    table = names(results)
    a = results["analysis"]
    lines = [f"**Plan.** {a['plan_line']}", stage_line(a), claim_line(a)]
    synthesis = results.get("synthesis")
    if synthesis:
        issues = synthesis["output"]["issues"]
        lines += ["", "**Top priorities now**"]
        for n, index in enumerate(synthesis["priority_actions"][:3], start=1):
            issue = issues[index]
            lines.append(f"{n}. {issue['title']} ({reader_list(issue_readers(issue), table)})")
        if synthesis["parked"]:
            lines.append(f"Parked for a later draft: {len(synthesis['parked'])} issue(s), listed in the report.")
    cold = results.get("cold_read")
    if cold and cold.get("claim_check"):
        checks = [f"{CHECK_LABEL[c['check']].lower()}: {RESULT_LABEL[c['result']].lower()}"
                  for c in cold["claim_check"]["checks"] if c["result"] != "not_applicable"]
        lines += ["", "**Cold read:** " + "; ".join(checks)]
    if synthesis:
        tradeoffs = synthesis["output"].get("tradeoffs", [])
        if tradeoffs:
            t = tradeoffs[0]
            sides = " vs. ".join(table.get(s["reader"], s["reader"]) for s in t["sides"])
            lines += ["", f"**Biggest tradeoff:** {sides} — {t['note'] or t['sides'][0]['wants']}"]
        plan = synthesis["output"]["next_steps"].get("feedback_plan", [])
        if plan:
            lines += ["", f"**Who to ask next:** {plan[0]['who']} — “{plan[0]['ask']}”"]
    rw = results["quality"]["related_work"]
    if rw["verified"]:
        lines += ["", f"**Related work:** {rw['verified']} named work{'s' if rw['verified'] > 1 else ''} found by "
                      "search and linked in the report"]
    lines += ["", "**Before you rely on this**"] + limitation_lines(results)
    if report_path:
        lines += ["", f"Full report: {report_path}"]
    return "\n".join(lines) + "\n"


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("results")
    parser.add_argument("--out")
    parser.add_argument("--summary", action="store_true", help="print the short chat summary instead")
    args = parser.parse_args(argv)
    results = json.loads(Path(args.results).read_text(encoding="utf-8"))
    text = render_summary(results, args.out) if args.summary else render_report(results)
    if args.out and not args.summary:
        Path(args.out).write_text(text, encoding="utf-8")
    else:
        sys.stdout.write(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
